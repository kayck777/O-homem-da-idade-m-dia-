import { BankLoan, NightEnemy, RepairablePart, ShopItem, ShopUpgrade, VisitorEncounter } from './types';

export const COLOR_VARIANTS = {
  dagger: {
    common: {
      name: 'Adaga de Ferro',
      baseName: 'Adaga',
      rarity: 'common' as const,
      colorHex: '#9ca3af',
      baseValue: 35,
      description: 'Lâmina comum de ferro cinza.',
    },
    rare: {
      name: 'Adaga Cobalto Rara',
      baseName: 'Adaga',
      rarity: 'rare_variant' as const,
      colorHex: '#38bdf8',
      baseValue: 165,
      description: 'Variante rara de aço azul-cobalto de alta raridade.',
    },
    chance: 0.16,
  },
  ring: {
    common: {
      name: 'Anel de Latão',
      baseName: 'Anel',
      rarity: 'common' as const,
      colorHex: '#d97706',
      baseValue: 28,
      description: 'Anel comum de metal amarelado.',
    },
    rare: {
      name: 'Anel Esmeralda Raro',
      baseName: 'Anel',
      rarity: 'rare_variant' as const,
      colorHex: '#10b981',
      baseValue: 180,
      description: 'Variante rara verde-esmeralda com pedra luminosa.',
    },
    chance: 0.15,
  },
  shield: {
    common: {
      name: 'Broquel de Carvalho',
      baseName: 'Escudo',
      rarity: 'common' as const,
      colorHex: '#92400e',
      baseValue: 45,
      description: 'Escudo simples de madeira marrom.',
    },
    rare: {
      name: 'Broquel Carmesim Raro',
      baseName: 'Escudo',
      rarity: 'rare_variant' as const,
      colorHex: '#f43f5e',
      baseValue: 195,
      description: 'Variante rara vermelho-carmesim muito cobiçada.',
    },
    chance: 0.15,
  },
};

export const MYTHIC_DEFENSE_ITEMS: ShopItem[] = [
  {
    id: 'myth-guards',
    name: 'Brasão da Guarda Mítico',
    baseName: 'Brasão Mítico',
    rarity: 'mythic',
    colorHex: '#f59e0b',
    baseValue: 130,
    mythicEffect: 'guards_gangs',
    description: 'Fortalece seus guardas contra ataques de gangues.',
  },
  {
    id: 'myth-witch',
    name: 'Amuleto Anti-Bruxaria Mítico',
    baseName: 'Amuleto Mítico',
    rarity: 'mythic',
    colorHex: '#c084fc',
    baseValue: 135,
    mythicEffect: 'ward_witches',
    description: 'Reforça suas proteções contra feitiços de bruxas.',
  },
];

export function rollVariantItem(slot: 'dagger' | 'ring' | 'shield', tag: string): ShopItem {
  const entry = COLOR_VARIANTS[slot];
  const rare = Math.random() < entry.chance;
  const pick = rare ? entry.rare : entry.common;
  return { ...pick, id: `${slot}-${tag}-${Math.random().toString(36).slice(2, 6)}` };
}

const MYTHIC_LEGENDS_POOL: VisitorEncounter[] = [
  {
    id: 'legend-arthur',
    name: 'Arthur',
    coverRole: 'Andarilho Bêbado',
    archetype: 'arthur',
    trueNature: 'legend_relic',
    shirtColor: '#991b1b',
    hairColor: '#ca8a04',
    accentColor: '#fde047',
    maxPatience: 4,
    initialSpeech: '*Hic*... Meu tempo já se foi... mas essa espada ainda tem peso.',
    askingPrice: 165,
    trueValue: 350,
    item: {
      id: 'excalibur-item',
      name: 'Excalibur Desgastada',
      baseName: 'Lâmina Lendária',
      rarity: 'legendary',
      colorHex: '#facc15',
      baseValue: 350,
      description: 'Espada lendária na mão de um homem acabado de cachaça e sem grana.',
    },
    appraisalClue: 'Relíquia lendária autêntica; o dono está na pindaíba de cachaça.',
    dialogues: [
      {
        id: 'a1',
        label: 'Você parece alguém famoso... era um guerreiro antigo?',
        reply: 'Guerreiro? *Solta um riso rouco*... Já tive reino e mesa redonda. Hoje só tenho sede.',
      },
      {
        id: 'a2',
        label: 'Por que você tá nessa situação?',
        reply: 'Quando o rei cai do cavalo e vira muita cachaça, ninguém paga fiado.',
      },
    ],
  },
  {
    id: 'legend-poseidon',
    name: 'Estranho das Marés',
    coverRole: 'Viajante Encharcado',
    archetype: 'poseidon',
    trueNature: 'legend_relic',
    shirtColor: '#0369a1',
    hairColor: '#e2e8f0',
    accentColor: '#38bdf8',
    maxPatience: 4,
    initialSpeech: 'Não é água do mar nisso aqui... é só suor salgado. Sim, suor.',
    askingPrice: 175,
    trueValue: 365,
    item: {
      id: 'trident-item',
      name: 'Tridente de Poseidon',
      baseName: 'Tridente Lendário',
      rarity: 'legendary',
      colorHex: '#22d3ee',
      baseValue: 365,
      description: 'Tridente antigo com estalo sutil de maré alta.',
    },
    appraisalClue: 'Artefato lendário de energia marítima; ele disfarça ter vindo do mar.',
    dialogues: [
      {
        id: 'p1',
        label: 'Você não é meio estranho? Veio do mar?',
        reply: 'Do mar? Eu? Haha, jamais! Só cuidado quando a tempestade bater no porto...',
      },
    ],
  },
  {
    id: 'legend-thor',
    name: 'Bram',
    coverRole: 'Brutamontes Barbudo',
    archetype: 'thor',
    trueNature: 'legend_relic',
    shirtColor: '#374151',
    hairColor: '#f59e0b',
    accentColor: '#fbbf24',
    maxPatience: 4,
    initialSpeech: 'Não teve trovão nenhum! Foi só o estômago roncando sem grana.',
    askingPrice: 185,
    trueValue: 380,
    item: {
      id: 'mjolnir-item',
      name: 'Martelo do Trovão (Mjölnir)',
      baseName: 'Martelo Lendário',
      rarity: 'legendary',
      colorHex: '#93c5fd',
      baseValue: 380,
      description: 'Martelo pesado gravado com runas nórdicas.',
    },
    appraisalClue: 'Relíquia nórdica genuína; o portador está duro e sem glória.',
    dialogues: [
      {
        id: 't1',
        label: 'Você parece um deus nórdico na pindaíba...',
        reply: 'Deus? Que nada, só um cara grande com braço cansado e bolso vazio.',
      },
    ],
  },
  {
    id: 'legend-pharaoh',
    name: 'Seti',
    coverRole: 'Viajante das Areias',
    archetype: 'pharaoh',
    trueNature: 'legend_relic',
    shirtColor: '#78350f',
    hairColor: '#111827',
    accentColor: '#eab308',
    maxPatience: 4,
    initialSpeech: 'As areias guardam segredos... e meu bolso guarda apenas poeira.',
    askingPrice: 170,
    trueValue: 355,
    item: {
      id: 'scarab-item',
      name: 'Escaravelho do Faraó',
      baseName: 'Relíquia Real',
      rarity: 'legendary',
      colorHex: '#eab308',
      baseValue: 355,
      description: 'Amuleto funerário egípcio entalhado em ouro antigo.',
    },
    appraisalClue: 'Peça real egípcia de alto valor histórico e arcano.',
    dialogues: [
      {
        id: 'ph1',
        label: 'Você veio de terras de faraós?',
        reply: 'Tumbas são frias e silenciosas. Ouro de faraó compra comida hoje em dia?',
      },
    ],
  },
  {
    id: 'legend-trickster',
    name: 'Mercúrio / Oráculo Liso',
    coverRole: 'Aventureiro Falido',
    archetype: 'trickster',
    trueNature: 'legend_relic',
    shirtColor: '#4338ca',
    hairColor: '#d97706',
    accentColor: '#a5b4fc',
    maxPatience: 4,
    initialSpeech: 'Eu previ que você ia abrir esta loja... só não previ ficar sem troco.',
    askingPrice: 150,
    trueValue: 310,
    item: {
      id: 'sandals-item',
      name: 'Sandália Alada Gasta',
      baseName: 'Relíquia Rápida',
      rarity: 'legendary',
      colorHex: '#818cf8',
      baseValue: 310,
      description: 'Sandália leve com asas gastas e passos rápidos.',
    },
    appraisalClue: 'Relíquia ágil autêntica; o dono esticou a sorte além da conta.',
    dialogues: [
      {
        id: 'tr1',
        label: 'Você parece um trapaceiro ou mensageiro antigo.',
        reply: 'Mensageiro sim; trapaceiro é palavra forte para quem só estica o prazo.',
      },
    ],
  },
];

export function buildDayVisitors(day: number): VisitorEncounter[] {
  const count = 10 + ((day * 3 + 2) % 6);
  const u = `${day}`;

  const pool: VisitorEncounter[] = [
    {
      id: `v1-${u}`,
      name: 'Tomás',
      coverRole: 'Viajante da Estrada',
      archetype: 'ambiguous',
      trueNature: 'stolen_goods',
      shirtColor: '#15803d',
      hairColor: '#451a03',
      accentColor: '#86efac',
      maxPatience: 3,
      initialSpeech: 'Achei isso num acampamento vazio... passo baratinho se fechar logo.',
      askingPrice: 40,
      trueValue: 50,
      item: {
        id: `it1-${u}`,
        name: 'Adaga de Ferro',
        baseName: 'Adaga',
        rarity: 'common',
        colorHex: '#9ca3af',
        baseValue: 50,
        isStolen: true,
        description: 'Parece comum, mas pode ter origem duvidosa.',
      },
      appraisalClue: 'Brasão raspado na lâmina: item roubado!',
      dialogues: [
        { id: 'd1a', label: 'De onde veio isso?', reply: 'Do norte... não precisa anotar meu nome.', moodShift: -1 },
      ],
    },
    {
      id: `v2-${u}`,
      name: 'Lorde Vane',
      coverRole: 'Colecionador',
      archetype: 'rich_bunk',
      trueNature: 'fake_junk',
      shirtColor: '#581c87',
      hairColor: '#d1d5db',
      accentColor: '#facc15',
      maxPatience: 3,
      initialSpeech: 'Uma peça rara de salão. Poucos têm olho para o que trago.',
      askingPrice: 95,
      trueValue: 10,
      item: {
        id: `it2-${u}`,
        name: 'Anel de Latão',
        baseName: 'Anel',
        rarity: 'junk',
        colorHex: '#d97706',
        baseValue: 10,
        description: 'Ele fala como se fosse ouro puro...',
      },
      appraisalClue: 'Metal barato sem valor real; pura lábia de rico metido.',
      dialogues: [
        { id: 'd2a', label: 'Isso vale mesmo tanto?', reply: 'Apenas nobres entendem essa sofisticação.', moodShift: -1 },
      ],
    },
    {
      id: `v3-${u}`,
      name: 'Zé Pinga',
      coverRole: 'Andarilho',
      archetype: 'drunk_lucky',
      trueNature: 'rare_treasure',
      shirtColor: '#854d0e',
      hairColor: '#78350f',
      accentColor: '#fde047',
      maxPatience: 4,
      initialSpeech: 'O pimentão virou general... e o esquilo pagou meu imposto!',
      askingPrice: 50,
      trueValue: 180,
      item: rollVariantItem('dagger', `drunk-${u}`),
      appraisalClue: 'Apesar do papo sem nexo, o item é excelente de verdade!',
      dialogues: [
        { id: 'd3a', label: 'Você tá falando coisa com coisa?', reply: 'Coisa com coisa é chato! Pega o treco aí!' },
      ],
    },
    {
      id: `v4-${u}`,
      name: 'Kuro',
      coverRole: 'Capuz Sombrio',
      archetype: 'ninja_raider',
      trueNature: 'raider_threat',
      shirtColor: '#111827',
      hairColor: '#09090b',
      accentColor: '#ef4444',
      maxPatience: 2,
      initialSpeech: 'Hora do assalto! Cinco shurikens no ar — acerte com a pistola!',
      askingPrice: 0,
      trueValue: 120,
      item: {
        id: `it4-${u}`,
        name: 'Lâmina Oculta',
        baseName: 'Arma Ninja',
        rarity: 'rare_variant',
        colorHex: '#ef4444',
        baseValue: 120,
        description: 'Assalto rápido com shurikens!',
      },
      appraisalClue: 'Ameaça de assalto! Prepare a pistola ou a 12.',
      dialogues: [
        { id: 'd4a', label: 'Vai embora daqui!', reply: 'Só depois de testar seus reflexos!' },
      ],
    },
    {
      id: `v5-${u}`,
      name: 'Morgana',
      coverRole: 'Mercadora Arcana',
      archetype: 'witch',
      trueNature: 'witch_curse',
      shirtColor: '#4c1d95',
      hairColor: '#1e1b4b',
      accentColor: '#c084fc',
      maxPatience: 3,
      initialSpeech: 'Quer negociar ou encarar meu feitiço? Ache 5 palavras no livro!',
      askingPrice: 75,
      trueValue: 140,
      item: {
        id: `it5-${u}`,
        name: 'Orbe de Névoa Roxa',
        baseName: 'Relíquia Arcana',
        rarity: 'mythic',
        colorHex: '#a855f7',
        baseValue: 140,
        mythicEffect: 'ward_witches',
        description: 'Aura roxa se acende quando ela conjura.',
      },
      appraisalClue: 'Bruxa com feitiço ativo; use o livro ou proteção anti-bruxas.',
      dialogues: [
        { id: 'd5a', label: 'Que magia é essa?', reply: 'Um feitiço que só o livro desfaz!' },
      ],
    },
    {
      id: `v6-${u}`,
      name: 'Bia',
      coverRole: 'Moradora',
      archetype: 'ambiguous',
      trueNature: 'clean_fair',
      shirtColor: '#0f766e',
      hairColor: '#7c2d12',
      accentColor: '#5eead4',
      maxPatience: 4,
      initialSpeech: 'Vim oferecer esse item para fazermos um negócio justo.',
      askingPrice: 45,
      trueValue: 65,
      item: rollVariantItem('shield', `bia-${u}`),
      appraisalClue: 'Origem limpa e avaliação favorável.',
      dialogues: [
        { id: 'd6a', label: 'Pode contar a história do item?', reply: 'Veio da oficina da vila, sem segredo.' },
      ],
    },
    {
      id: `v7-${u}`,
      name: 'Rafa',
      coverRole: 'Aventureiro',
      archetype: 'ambiguous',
      trueNature: 'stolen_goods',
      shirtColor: '#1e3a8a',
      hairColor: '#27272a',
      accentColor: '#93c5fd',
      maxPatience: 3,
      initialSpeech: 'Preço baixo para sair hoje. Topa fechar agora?',
      askingPrice: 38,
      trueValue: 48,
      item: {
        id: `it7-${u}`,
        name: 'Broquel de Carvalho',
        baseName: 'Escudo',
        rarity: 'common',
        colorHex: '#92400e',
        baseValue: 48,
        isStolen: true,
        description: 'Parece simples, mas pode ser produto de roubo.',
      },
      appraisalClue: 'Item roubado de guarda! Use a 12 se ele avançar.',
      dialogues: [
        { id: 'd7a', label: 'Por que tão barato?', reply: 'Só quero ouro rápido na mão.', moodShift: -1 },
      ],
    },
  ];

  const list: VisitorEncounter[] = [];
  for (let i = 0; i < count; i++) {
    if (i === count - 1 && day % 2 === 1) {
      const legend = MYTHIC_LEGENDS_POOL[Math.floor((day - 1) / 2) % MYTHIC_LEGENDS_POOL.length];
      list.push({ ...legend, id: `${legend.id}-${u}-${i}` });
    } else {
      const base = pool[(i + day) % pool.length];
      list.push({
        ...base,
        id: `${base.id}-${u}-${i}`,
        item:
          base.trueNature === 'clean_fair' || base.trueNature === 'rare_treasure'
            ? rollVariantItem(i % 2 === 0 ? 'ring' : 'dagger', `${u}-${i}`)
            : { ...base.item, id: `${base.item.id}-${i}` },
      });
    }
  }

  return list;
}

export function createInitialLoans(): BankLoan[] {
  return [
    {
      id: 'loan-1',
      lender: 'Banco Real do Vale',
      principal: 180,
      dueDay: 4,
      taken: false,
      repaid: false,
      defaultedInCollapse: false,
    },
    {
      id: 'loan-2',
      lender: 'Câmara de Crédito do Norte',
      principal: 320,
      dueDay: 6,
      taken: false,
      repaid: false,
      defaultedInCollapse: false,
    },
  ];
}

export function createInitialRepairs(): RepairablePart[] {
  return [
    { id: 'counter', name: 'Balcão de Madeira', cost: 45, durability: 75 },
    { id: 'door', name: 'Porta da Entrada', cost: 55, durability: 70 },
    { id: 'torches', name: 'Tochas & Iluminação', cost: 35, durability: 80 },
    { id: 'wall', name: 'Muralha / Fachada', cost: 70, durability: 75 },
  ];
}

export function createInitialUpgrades(): ShopUpgrade[] {
  return [
    {
      id: 'haggle',
      name: 'Arte da Barganha',
      description: 'Melhora negociações e reduz perda de paciência.',
      level: 1,
      maxLevel: 5,
      baseCost: 70,
    },
    {
      id: 'appraisal',
      name: 'Olho de Avaliador',
      description: 'Aumenta o valor de revenda dos itens.',
      level: 1,
      maxLevel: 5,
      baseCost: 80,
    },
    {
      id: 'guards',
      name: 'Evoluir Menino & Guardas',
      description: 'Fortalece o menino guarda e chama novos guardas para a fortaleza.',
      level: 1,
      maxLevel: 5,
      baseCost: 85,
    },
    {
      id: 'witch_ward',
      name: 'Feitiço Anti-Bruxas',
      description: 'Protege contra feitiços e auras roxas das bruxas.',
      level: 0,
      maxLevel: 4,
      baseCost: 85,
    },
    {
      id: 'fortress',
      name: 'Expandir para Fortaleza',
      description: 'Evolui a fachada externa até virar uma fortaleza.',
      level: 1,
      maxLevel: 4,
      baseCost: 120,
    },
  ];
}

export function createNightWave(day: number): NightEnemy[] {
  const enemies: NightEnemy[] = [
    {
      id: `en-1-${day}`,
      name: 'Besta da Mata',
      hp: 30 + day * 8,
      maxHp: 30 + day * 8,
      xPct: 26,
      isGang: false,
    },
    {
      id: `en-2-${day}`,
      name: 'Saqueador de Gangue',
      hp: 40 + day * 10,
      maxHp: 40 + day * 10,
      xPct: 74,
      isGang: true,
    },
  ];

  if (day >= 2) {
    enemies.push({
      id: `en-3-${day}`,
      name: 'Bruto da Gangue',
      hp: 55 + day * 12,
      maxHp: 55 + day * 12,
      xPct: 50,
      isGang: true,
    });
  }

  return enemies;
}
