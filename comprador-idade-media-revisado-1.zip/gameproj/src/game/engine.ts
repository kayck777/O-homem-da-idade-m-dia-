import {
  buildDayVisitors,
  createInitialLoans,
  createInitialRepairs,
  createInitialUpgrades,
  createNightWave,
} from './data';
import { GameState } from './types';

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function getUpgradeCost(baseCost: number, level: number): number {
  return Math.round(baseCost * Math.pow(1.45, Math.max(0, level)));
}

export function createInitialGameState(muted = false): GameState {
  const day = 1;
  const queue = buildDayVisitors(day);
  const first = queue[0] ?? null;

  return {
    day,
    cutsceneStep: 0,
    isCollapseEra: false,
    gold: 165,
    reputation: 50,
    suspicion: 0,
    supplies: 3,
    materials: 4,
    shopHp: 100,
    maxShopHp: 100,
    shotgunAmmo: 3,
    pistolAmmo: 10,
    appraisalsLeft: 2,
    boyGuardLevel: 1,
    guardsCount: 1,
    guardsPower: 18,
    witchWardPower: 0,
    fortressLevel: 1,
    viewMode: 'interior',
    minigame: { type: 'none' },
    visitorQueue: queue,
    visitorIndex: 0,
    currentVisitor: first,
    animStage: first ? 'entering' : 'door_closed',
    visitorPatience: first ? first.maxPatience : 0,
    currentOffer: first ? first.askingPrice : 0,
    speechBubble: first ? first.initialSpeech : '',
    logMessage: first
      ? `Dia 1 começou! ${first.name} (${first.coverRole}) entrou pela porta.`
      : 'Dia 1 começou!',
    nightReport: '',
    nightEnemies: [],
    loans: createInitialLoans(),
    inventory: [
      {
        id: 'starter-dagger',
        name: 'Adaga de Ferro',
        baseName: 'Adaga',
        rarity: 'common',
        colorHex: '#9ca3af',
        baseValue: 35,
        description: 'Lâmina comum de ferro cinza.',
      },
    ],
    repairs: createInitialRepairs(),
    upgrades: createInitialUpgrades(),
    muted,
  };
}

export function advanceToNextVisitor(state: GameState): GameState {
  const nextIdx = state.visitorIndex + 1;
  if (nextIdx >= state.visitorQueue.length) {
    return {
      ...state,
      visitorIndex: nextIdx,
      currentVisitor: null,
      animStage: 'door_closed',
      minigame: { type: 'none' },
      speechBubble: '',
      logMessage:
        'Todos os visitantes do dia passaram pelo balcão! Clique em EXTERIOR / NOITE.',
    };
  }

  const next = state.visitorQueue[nextIdx];
  return {
    ...state,
    visitorIndex: nextIdx,
    currentVisitor: next,
    animStage: 'entering',
    minigame: { type: 'none' },
    visitorPatience: next.maxPatience,
    currentOffer: next.askingPrice,
    speechBubble: next.initialSpeech,
    logMessage: `${next.name} (${next.coverRole}) entrou pela porta.`,
  };
}

export function evaluateCurrentItem(state: GameState): GameState {
  const v = state.currentVisitor;
  if (!v) return state;
  if (state.appraisalsLeft <= 0) {
    return {
      ...state,
      logMessage: 'Você já usou as 2 avaliações de hoje!',
    };
  }

  return {
    ...state,
    appraisalsLeft: state.appraisalsLeft - 1,
    logMessage: `AVALIAÇÃO: ${v.appraisalClue} (Valor real: ~${v.trueValue}g)`,
  };
}

export function buyFromCounter(state: GameState): GameState {
  const v = state.currentVisitor;
  if (!v) return state;

  if (v.trueNature === 'raider_threat') {
    return {
      ...state,
      minigame: { type: 'ninja_shuriken', attackerName: v.name, hitsNeeded: 5 },
      speechBubble: 'Na verdade eu estou aqui para te roubar! Acerte as 5 shurikens!',
      logMessage: 'O ninja puxou assalto direto! Acerte as 5 shurikens com a pistola!',
    };
  }

  if (v.trueNature === 'witch_curse' && state.witchWardPower < 25) {
    return {
      ...state,
      minigame: {
        type: 'witch_wordsearch',
        witchName: v.name,
        wordsToFind: ['LUZ', 'ALMA', 'FOGO', 'ROCHA', 'RUNA'],
        timeLimitSec: 15,
      },
      speechBubble: 'Meu feitiço começou! Ache as 5 palavras em 15 segundos!',
      logMessage: 'A bruxa ativou o Livro Arcano! Ache 5 palavras em 15s!',
    };
  }

  if (state.gold < state.currentOffer) {
    return {
      ...state,
      logMessage: `Ouro insuficiente! Precisa de ${state.currentOffer}g.`,
    };
  }

  const isStolen = v.trueNature === 'stolen_goods' || Boolean(v.item.isStolen);
  const isJunk = v.trueNature === 'fake_junk';
  const repDelta = isStolen
    ? -6
    : isJunk
      ? -3
      : v.trueNature === 'legend_relic'
        ? 10
        : v.item.rarity === 'rare_variant'
          ? 6
          : 3;

  const purchaseLog = isStolen
    ? `Comprou ${v.item.name} por ${state.currentOffer}g — era roubado! (+15% suspeita)`
    : isJunk
      ? `Comprou ${v.item.name} por ${state.currentOffer}g — cilada! Vale só ${v.item.baseValue}g.`
      : `Comprou ${v.item.name} por ${state.currentOffer}g!`;

  const updated: GameState = {
    ...state,
    gold: state.gold - state.currentOffer,
    reputation: clamp(state.reputation + repDelta, 0, 100),
    suspicion: clamp(state.suspicion + (isStolen ? 15 : 0), 0, 100),
    inventory: [v.item, ...state.inventory],
  };

  const next = advanceToNextVisitor(updated);
  return {
    ...next,
    logMessage: purchaseLog,
  };
}

export function takeBankLoan(state: GameState, loanId: string): GameState {
  const loan = state.loans.find((l) => l.id === loanId);
  if (!loan || loan.taken || state.isCollapseEra) return state;

  return {
    ...state,
    gold: state.gold + loan.principal,
    loans: state.loans.map((l) => (l.id === loanId ? { ...l, taken: true } : l)),
    logMessage: `Empréstimo de +${loan.principal}g recebido de ${loan.lender} (vence Dia ${loan.dueDay}).`,
  };
}

export function enterExteriorNight(state: GameState): GameState {
  const enemies = createNightWave(state.day);
  const mythicGuardsBonus =
    state.inventory.filter((i) => i.mythicEffect === 'guards_gangs').length * 22;
  const mythicWitchBonus =
    state.inventory.filter((i) => i.mythicEffect === 'ward_witches').length * 20;

  const totalDefense =
    state.fortressLevel * 22 +
    state.guardsPower +
    state.guardsCount * 10 +
    state.boyGuardLevel * 8 +
    mythicGuardsBonus +
    Math.floor((state.witchWardPower + mythicWitchBonus) * 0.4);

  const enemyPower =
    enemies.reduce((sum, e) => sum + e.hp, 0) +
    (state.isCollapseEra ? 25 : 0) +
    Math.floor(state.suspicion * 0.4);

  const repelled = totalDefense >= enemyPower;

  if (repelled) {
    const loot = 45 + state.day * 15;
    const report = `Defesa noturna vencida! Fortaleza Nv.${state.fortressLevel} e ${state.guardsCount} guarda(s) (Força ${totalDefense} vs ${enemyPower}) repeliram ${enemies.length} invasores. Saque: +${loot}g.`;
    return {
      ...state,
      viewMode: 'exterior_night',
      minigame: { type: 'none' },
      gold: state.gold + loot,
      reputation: clamp(state.reputation + 5, 0, 100),
      nightEnemies: enemies.map((e) => ({ ...e, hp: 0 })),
      nightReport: report,
      logMessage: report,
    };
  }

  const dmg = Math.min(35, Math.max(10, Math.round((enemyPower - totalDefense) * 0.35)));
  const goldStolen = Math.min(state.gold, 25 + state.day * 5);
  const report = `Cerco pesado na noite ${state.day}! Os invasores romperam a defesa (${totalDefense} vs ${enemyPower}): -${dmg} HP na loja e -${goldStolen}g levados.`;

  return {
    ...state,
    viewMode: 'exterior_night',
    minigame: { type: 'none' },
    gold: Math.max(0, state.gold - goldStolen),
    shopHp: Math.max(10, state.shopHp - dmg),
    repairs: state.repairs.map((r) =>
      r.id === 'wall' || r.id === 'door'
        ? { ...r, durability: Math.max(10, r.durability - 15) }
        : r
    ),
    nightEnemies: enemies,
    nightReport: report,
    logMessage: report,
  };
}

export function startNextDayFromNight(state: GameState): GameState {
  const nextDay = state.day + 1;
  let collapseEra = state.isCollapseEra || nextDay >= 5;
  const updatedLoans = state.loans.map((l) => {
    if (l.taken && !l.repaid && nextDay > l.dueDay) {
      collapseEra = true;
      return { ...l, defaultedInCollapse: true };
    }
    return l;
  });

  const queue = buildDayVisitors(nextDay);
  const first = queue[0] ?? null;

  return {
    ...state,
    day: nextDay,
    isCollapseEra: collapseEra,
    appraisalsLeft: 2,
    viewMode: 'interior',
    minigame: { type: 'none' },
    visitorQueue: queue,
    visitorIndex: 0,
    currentVisitor: first,
    animStage: first ? 'entering' : 'door_closed',
    visitorPatience: first ? first.maxPatience : 0,
    currentOffer: first ? first.askingPrice : 0,
    speechBubble: first ? first.initialSpeech : '',
    nightReport: '',
    nightEnemies: [],
    loans: updatedLoans,
    logMessage: collapseEra
      ? `Dia ${nextDay} aberto — ERA DO COLAPSO! Bancos travados e invasões mais fortes.`
      : `Dia ${nextDay} aberto! Avaliações recarregadas (2/2).`,
  };
}
