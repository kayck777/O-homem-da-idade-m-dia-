import {
  advanceToNextVisitor,
  buyFromCounter,
  createInitialGameState,
  enterExteriorNight,
  evaluateCurrentItem,
  getUpgradeCost,
  startNextDayFromNight,
  takeBankLoan,
} from './engine';

function assert(cond: boolean, message: string): void {
  if (!cond) throw new Error(`Assertion failed: ${message}`);
}

export function runSmokeTests(): void {
  let state = createInitialGameState(true);
  assert(state.day === 1, 'Starts on day 1');
  assert(state.appraisalsLeft === 2, 'Starts with 2 appraisals');
  assert(getUpgradeCost(70, 1) > 70, 'Upgrade cost scales');

  state = evaluateCurrentItem(state);
  assert(state.appraisalsLeft === 1, 'Evaluation consumes 1 appraisal');

  state = buyFromCounter(state);
  state = advanceToNextVisitor(state);
  state = takeBankLoan(state, 'loan-1');
  assert(state.loans[0].taken, 'Loan taken');

  state = enterExteriorNight(state);
  assert(state.viewMode === 'exterior_night', 'Enters exterior_night');
  assert(state.nightReport.length > 0, 'Generates night report');

  state = startNextDayFromNight(state);
  assert(state.day === 2 && state.viewMode === 'interior', 'Starts Day 2 in interior');
  assert(state.appraisalsLeft === 2, 'Resets appraisals to 2 on new day');
}
