export type CharacterArchetype =
  | 'ambiguous'
  | 'drunk_lucky'
  | 'rich_bunk'
  | 'ninja_raider'
  | 'witch'
  | 'arthur'
  | 'poseidon'
  | 'thor'
  | 'pharaoh'
  | 'trickster';

export type TrueNature =
  | 'clean_fair'
  | 'stolen_goods'
  | 'fake_junk'
  | 'rare_treasure'
  | 'mythic_relic'
  | 'legend_relic'
  | 'raider_threat'
  | 'witch_curse';

export type ItemRarity = 'common' | 'rare_variant' | 'mythic' | 'legendary' | 'junk';

export type MythicEffectType = 'guards_gangs' | 'ward_witches';

export interface ShopItem {
  id: string;
  name: string;
  baseName: string;
  rarity: ItemRarity;
  colorHex: string;
  baseValue: number;
  isStolen?: boolean;
  mythicEffect?: MythicEffectType;
  description: string;
}

export interface DialogueChoice {
  id: string;
  label: string;
  reply: string;
  moodShift?: number;
  revealsHint?: boolean;
}

export interface VisitorEncounter {
  id: string;
  name: string;
  coverRole: string;
  archetype: CharacterArchetype;
  trueNature: TrueNature;
  shirtColor: string;
  hairColor: string;
  accentColor: string;
  maxPatience: number;
  initialSpeech: string;
  askingPrice: number;
  trueValue: number;
  item: ShopItem;
  appraisalClue: string;
  dialogues: DialogueChoice[];
}

export interface BankLoan {
  id: string;
  lender: string;
  principal: number;
  dueDay: number;
  taken: boolean;
  repaid: boolean;
  defaultedInCollapse: boolean;
}

export interface RepairablePart {
  id: 'counter' | 'door' | 'torches' | 'wall';
  name: string;
  cost: number;
  durability: number;
}

export type UpgradeId = 'haggle' | 'appraisal' | 'guards' | 'witch_ward' | 'fortress';

export interface ShopUpgrade {
  id: UpgradeId;
  name: string;
  description: string;
  level: number;
  maxLevel: number;
  baseCost: number;
}

export type GameViewMode = 'intro_cutscene' | 'interior' | 'exterior_night';

export type VisitorAnimStage =
  | 'entering'
  | 'handing_item'
  | 'at_counter'
  | 'leaving'
  | 'door_closed';

export type ActiveMinigame =
  | { type: 'none' }
  | { type: 'ninja_shuriken'; attackerName: string; hitsNeeded: number }
  | {
      type: 'witch_wordsearch';
      witchName: string;
      wordsToFind: string[];
      timeLimitSec?: number;
    }
  | { type: 'lock_puzzle'; targetCode: string; clue: string };

export interface NightEnemy {
  id: string;
  name: string;
  hp: number;
  maxHp: number;
  xPct: number;
  isGang: boolean;
}

export interface GameState {
  day: number;
  cutsceneStep: number;
  isCollapseEra: boolean;
  gold: number;
  reputation: number;
  suspicion: number;
  supplies: number;
  materials: number;
  shopHp: number;
  maxShopHp: number;
  shotgunAmmo: number;
  pistolAmmo: number;
  appraisalsLeft: number;
  boyGuardLevel: number;
  guardsCount: number;
  guardsPower: number;
  witchWardPower: number;
  fortressLevel: number;
  viewMode: GameViewMode;
  minigame: ActiveMinigame;
  visitorQueue: VisitorEncounter[];
  visitorIndex: number;
  currentVisitor: VisitorEncounter | null;
  animStage: VisitorAnimStage;
  visitorPatience: number;
  currentOffer: number;
  speechBubble: string;
  logMessage: string;
  nightReport: string;
  nightEnemies: NightEnemy[];
  loans: BankLoan[];
  inventory: ShopItem[];
  repairs: RepairablePart[];
  upgrades: ShopUpgrade[];
  muted: boolean;
}
