export type VisitorSoundArchetype =
  | 'ambiguous'
  | 'drunk_lucky'
  | 'rich_bunk'
  | 'ninja_raider'
  | 'witch'
  | 'arthur'
  | 'poseidon'
  | 'thor'
  | 'pharaoh'
  | 'trickster';

class MedievalShopAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;

  private muted = false;
  private playing = false;
  private mode: 'interior' | 'exterior_night' = 'interior';
  private timerId: number | null = null;
  private step = 0;

  // Melodia medieval em Ré menor / Dórico (mais encorpada e cadenciada)
  private readonly medievalLead = [
    293.66, 349.23, 440.0, 523.25, 440.0, 392.0, 349.23, 329.63,
    293.66, 329.63, 349.23, 440.0, 392.0, 349.23, 293.66, 220.0,
  ];
  private readonly medievalHarmony = [
    196.0, 220.0, 293.66, 349.23, 293.66, 261.63, 220.0, 196.0,
    174.61, 196.0, 220.0, 293.66, 261.63, 220.0, 174.61, 146.83,
  ];
  private readonly medievalDrone = [146.83, 146.83, 130.81, 130.81, 116.54, 116.54, 110.0, 110.0];

  private readonly nightLead = [220.0, 261.63, 311.13, 293.66, 261.63, 220.0, 196.0, 164.81];
  private readonly nightDrone = [110.0, 110.0, 98.0, 98.0, 87.31, 87.31, 82.41, 82.41];

  private ensureCtx(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;

    if (!this.ctx) {
      this.ctx = new AudioCtx();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.28;
      this.musicGain.connect(this.master);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.55;
      this.sfxGain.connect(this.master);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock(mode?: 'interior' | 'exterior_night'): void {
    if (mode) this.mode = mode;
    this.ensureCtx();
    if (!this.muted && !this.playing) {
      this.startMusic();
    }
  }

  public setMode(mode: 'interior' | 'exterior_night'): void {
    this.mode = mode;
  }

  public startMusic(): void {
    const ctx = this.ensureCtx();
    if (!ctx || !this.musicGain || this.playing) return;

    this.playing = true;
    this.step = 0;

    const tick = () => {
      if (!this.playing || !this.ctx || !this.musicGain) return;
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      const now = this.ctx.currentTime;
      const isNight = this.mode === 'exterior_night';
      const leadNotes = isNight ? this.nightLead : this.medievalLead;
      const droneNotes = isNight ? this.nightDrone : this.medievalDrone;
      const idx = this.step % leadNotes.length;
      const dIdx = this.step % droneNotes.length;

      // Alaúde / flauta medieval principal
      const lead = this.ctx.createOscillator();
      const leadEnv = this.ctx.createGain();
      lead.type = isNight ? 'sawtooth' : 'triangle';
      lead.frequency.setValueAtTime(leadNotes[idx], now);

      leadEnv.gain.setValueAtTime(0.001, now);
      leadEnv.gain.linearRampToValueAtTime(0.24, now + 0.025);
      leadEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.34);

      lead.connect(leadEnv);
      leadEnv.connect(this.musicGain);
      lead.start(now);
      lead.stop(now + 0.36);

      // Segunda voz (corte de quinta/terça medieval)
      if (!isNight) {
        const harm = this.ctx.createOscillator();
        const harmEnv = this.ctx.createGain();
        harm.type = 'sine';
        harm.frequency.setValueAtTime(this.medievalHarmony[idx], now);

        harmEnv.gain.setValueAtTime(0.001, now);
        harmEnv.gain.linearRampToValueAtTime(0.14, now + 0.03);
        harmEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

        harm.connect(harmEnv);
        harmEnv.connect(this.musicGain);
        harm.start(now);
        harm.stop(now + 0.34);
      }

      // Bordão grave contínuo
      const drone = this.ctx.createOscillator();
      const droneEnv = this.ctx.createGain();
      drone.type = 'triangle';
      drone.frequency.setValueAtTime(droneNotes[dIdx], now);

      droneEnv.gain.setValueAtTime(0.001, now);
      droneEnv.gain.linearRampToValueAtTime(0.22, now + 0.04);
      droneEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.43);

      drone.connect(droneEnv);
      droneEnv.connect(this.musicGain);
      drone.start(now);
      drone.stop(now + 0.45);

      this.step += 1;
    };

    tick();
    this.timerId = window.setInterval(tick, 440);
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.9, this.ctx.currentTime, 0.03);
    }
    if (!muted && !this.playing) {
      this.startMusic();
    }
  }

  public getMuted(): boolean {
    return this.muted;
  }

  private tone(
    fStart: number,
    fEnd: number,
    delay: number,
    dur: number,
    type: OscillatorType,
    vol: number
  ): void {
    const ctx = this.ensureCtx();
    if (!ctx || !this.sfxGain || this.muted) return;

    const start = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(fStart, start);
    if (fEnd !== fStart) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(32, fEnd), start + dur);
    }

    gain.gain.setValueAtTime(0.001, start);
    gain.gain.linearRampToValueAtTime(vol, start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, start + dur);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(start);
    osc.stop(start + dur + 0.02);
  }

  public playVisitorArrival(archetype: VisitorSoundArchetype): void {
    this.unlock('interior');
    switch (archetype) {
      case 'ninja_raider':
        this.tone(1100, 280, 0.0, 0.1, 'sawtooth', 0.32);
        this.tone(1760, 2200, 0.09, 0.14, 'square', 0.28);
        this.tone(1480, 540, 0.2, 0.12, 'triangle', 0.28);
        break;
      case 'witch':
        this.tone(220, 311.13, 0.0, 0.24, 'triangle', 0.32);
        this.tone(311.13, 466.16, 0.15, 0.28, 'sine', 0.32);
        this.tone(622.25, 932.33, 0.3, 0.26, 'triangle', 0.24);
        break;
      case 'drunk_lucky':
        this.tone(196, 174.61, 0.0, 0.15, 'triangle', 0.3);
        this.tone(155.56, 207.65, 0.16, 0.17, 'triangle', 0.3);
        this.tone(146.83, 123.47, 0.34, 0.2, 'sine', 0.26);
        break;
      case 'rich_bunk':
        this.tone(523.25, 523.25, 0.0, 0.11, 'triangle', 0.26);
        this.tone(659.25, 659.25, 0.11, 0.11, 'triangle', 0.26);
        this.tone(783.99, 783.99, 0.22, 0.2, 'triangle', 0.28);
        break;
      case 'arthur':
      case 'poseidon':
      case 'thor':
      case 'pharaoh':
      case 'trickster':
        this.tone(293.66, 293.66, 0.0, 0.13, 'square', 0.22);
        this.tone(369.99, 369.99, 0.13, 0.13, 'square', 0.22);
        this.tone(440.0, 440.0, 0.26, 0.15, 'square', 0.24);
        this.tone(587.33, 554.37, 0.42, 0.28, 'triangle', 0.28);
        break;
      case 'ambiguous':
      default:
        this.tone(392.0, 440.0, 0.0, 0.1, 'triangle', 0.24);
        this.tone(440.0, 493.88, 0.1, 0.13, 'triangle', 0.24);
        break;
    }
  }

  public playAimLock(): void {
    this.tone(660, 880, 0.0, 0.07, 'square', 0.22);
  }

  public playShotgunBlast(): void {
    this.tone(190, 38, 0.0, 0.32, 'sawtooth', 0.5);
    this.tone(115, 32, 0.02, 0.38, 'square', 0.38);
  }

  public playPistol(): void {
    this.tone(880, 190, 0.0, 0.09, 'square', 0.28);
  }

  public playDamageSound(): void {
    this.tone(150, 45, 0.0, 0.28, 'sawtooth', 0.44);
    this.tone(90, 30, 0.04, 0.34, 'square', 0.36);
  }

  public playTruckCrash(): void {
    this.tone(185, 165, 0.0, 0.22, 'sawtooth', 0.32);
    this.tone(233.08, 207.65, 0.02, 0.22, 'sawtooth', 0.28);
    this.tone(120, 30, 0.24, 0.4, 'sawtooth', 0.48);
  }

  public playStep(): void {
    this.tone(150, 85, 0.0, 0.06, 'square', 0.14);
  }

  public playCoin(): void {
    this.tone(987.77, 1318.51, 0.0, 0.13, 'triangle', 0.28);
  }

  public playHammer(): void {
    this.tone(260, 110, 0.0, 0.12, 'square', 0.25);
  }
}

export const medievalAudio = new MedievalShopAudio();
