import React, { useEffect, useState } from 'react';
import { medievalAudio } from './game/audio';
import { MYTHIC_DEFENSE_ITEMS, rollVariantItem } from './game/data';
import {
  advanceToNextVisitor,
  buyFromCounter,
  createInitialGameState,
  enterExteriorNight,
  evaluateCurrentItem,
  getUpgradeCost,
  startNextDayFromNight,
  takeBankLoan,
} from './game/engine';
import { GameState } from './game/types';

const SAVE_KEY = 'balcao_do_reino_v3_save';

const WORD_GRID = [
  ['L', 'U', 'Z', 'X', 'A', 'R'],
  ['M', 'O', 'R', 'U', 'L', 'N'],
  ['F', 'O', 'G', 'O', 'M', 'A'],
  ['R', 'O', 'C', 'H', 'A', 'T'],
  ['S', 'O', 'L', 'Z', 'A', 'O'],
  ['R', 'U', 'N', 'A', 'P', 'Q'],
];

const TARGET_WORDS: Record<string, [number, number][]> = {
  LUZ: [
    [0, 0],
    [0, 1],
    [0, 2],
  ],
  ALMA: [
    [0, 4],
    [1, 4],
    [2, 4],
    [3, 4],
  ],
  FOGO: [
    [2, 0],
    [2, 1],
    [2, 2],
    [2, 3],
  ],
  ROCHA: [
    [3, 0],
    [3, 1],
    [3, 2],
    [3, 3],
    [3, 4],
  ],
  RUNA: [
    [5, 0],
    [5, 1],
    [5, 2],
    [5, 3],
  ],
};

export function App() {
  const [state, setState] = useState<GameState>(() => {
    const base = createInitialGameState(false);
    if (typeof window !== 'undefined') {
      try {
        const raw = window.localStorage.getItem(SAVE_KEY);
        if (raw) {
          return { ...base, ...JSON.parse(raw) };
        }
      } catch {
        // Ignora erro de save
      }
    }
    return { ...base, viewMode: 'intro_cutscene' as GameState['viewMode'], cutsceneStep: 0 };
  });

  const [sideTab, setSideTab] = useState<'upgrade' | 'repair' | 'buy' | 'trade' | 'banco'>('buy');

  // Estado da 12 na mão + mirar
  const [shotgunDrawn, setShotgunDrawn] = useState(false);
  const [aimLocked, setAimLocked] = useState(false);
  const [shotgunRecoil, setShotgunRecoil] = useState(false);

  // Tela vermelha + sangue ao falhar
  const [bloodScreen, setBloodScreen] = useState(false);

  // Luzes piscando na bruxa
  const [witchFlicker, setWitchFlicker] = useState(false);

  // Minigame Ninja: 5 shurikens rápidas com pistola
  const [shurikenHits, setShurikenHits] = useState(0);
  const [shurikenX, setShurikenX] = useState(12);
  const [shurikenY, setShurikenY] = useState(34);

  // Minigame Bruxa: livro + caça-palavras de 5 palavras + 15s máximo
  const [foundWords, setFoundWords] = useState<string[]>([]);
  const [pickedCells, setPickedCells] = useState<[number, number][]>([]);
  const [witchTimer, setWitchTimer] = useState(15);

  useEffect(() => {
    medievalAudio.setMuted(state.muted);
    medievalAudio.setMode(state.viewMode === 'exterior_night' ? 'exterior_night' : 'interior');
  }, [state.muted, state.viewMode]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        window.localStorage.setItem(SAVE_KEY, JSON.stringify(state));
      } catch {
        // Ignora erro de save
      }
    }
  }, [state]);

  useEffect(() => {
    const unlock = () => {
      medievalAudio.unlock(state.viewMode === 'exterior_night' ? 'exterior_night' : 'interior');
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, [state.viewMode]);

  const triggerBloodDamage = (speech: string, log: string) => {
    medievalAudio.playDamageSound();
    setBloodScreen(true);
    setShotgunDrawn(false);
    setAimLocked(false);
    window.setTimeout(() => setBloodScreen(false), 850);

    setState((s) => ({
      ...s,
      gold: Math.max(0, s.gold - 25),
      shopHp: Math.max(10, s.shopHp - 20),
      minigame: { type: 'none' },
      animStage: 'leaving',
      speechBubble: speech,
      logMessage: log,
    }));

    window.setTimeout(() => {
      setState((s) => advanceToNextVisitor(s));
    }, 2400);
  };

  // Quando o visitante entra: som característico + animação + ninja direto se for o caso
  useEffect(() => {
    if (state.viewMode !== 'interior' || !state.currentVisitor) return;
    const v = state.currentVisitor;

    setShotgunDrawn(false);
    setAimLocked(false);
    medievalAudio.playVisitorArrival(v.archetype);

    const t1 = window.setTimeout(() => {
      medievalAudio.playStep();
      setState((s) => {
        if (!s.currentVisitor || s.currentVisitor.id !== v.id) return s;
        // Ninja já chega assumindo o roubo e puxando luta direta (nem sempre, mas quando vem é direto)
        const directNinjaAssault = v.archetype === 'ninja_raider';
        // Bruxa puxa desafio de 15s em parte das vezes de forma direta
        const directWitchSpell = v.archetype === 'witch' && s.day % 2 === 1;

        return {
          ...s,
          animStage: 'handing_item',
          speechBubble: directNinjaAssault
            ? 'Na verdade eu estou aqui para te roubar! Cinco shurikens no ar — acerte com a pistola!'
            : directWitchSpell
            ? 'Meu feitiço começou! Você tem 15 segundos para achar 5 palavras no livro!'
            : v.initialSpeech,
          minigame: directNinjaAssault
            ? { type: 'ninja_shuriken', attackerName: v.name, hitsNeeded: 5 }
            : directWitchSpell
            ? {
                type: 'witch_wordsearch',
                witchName: v.name,
                wordsToFind: ['LUZ', 'ALMA', 'FOGO', 'ROCHA', 'RUNA'],
                timeLimitSec: 15,
              }
            : { type: 'none' },
        };
      });
    }, 550);

    const t2 = window.setTimeout(() => {
      setState((s) =>
        s.currentVisitor?.id === v.id && s.animStage === 'handing_item'
          ? { ...s, animStage: 'at_counter' }
          : s
      );
    }, 1050);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [state.viewMode, state.currentVisitor?.id]);

  // Luzes piscando em roxo quando a bruxa está na cena
  useEffect(() => {
    if (state.currentVisitor?.archetype !== 'witch') {
      setWitchFlicker(false);
      return;
    }
    const id = window.setInterval(() => setWitchFlicker((w) => !w), 220);
    return () => clearInterval(id);
  }, [state.currentVisitor?.id, state.currentVisitor?.archetype]);

  // Minigame Ninja: 5 shurikens rápidas
  useEffect(() => {
    if (state.minigame.type !== 'ninja_shuriken') return;
    setShurikenHits(0);
    setShurikenX(10);
    setShurikenY(32);

    const id = window.setInterval(() => {
      setShurikenX((prev) => {
        if (prev >= 86) {
          setShurikenY(22 + Math.floor(Math.random() * 36));
          return 10;
        }
        return prev + 18;
      });
    }, 155);

    return () => clearInterval(id);
  }, [state.minigame.type]);

  // Minigame Bruxa: cronômetro de 15s máximo
  useEffect(() => {
    if (state.minigame.type !== 'witch_wordsearch') return;
    setFoundWords([]);
    setPickedCells([]);
    setWitchTimer(15);

    const id = window.setInterval(() => {
      setWitchTimer((prev) => {
        if (prev <= 1) {
          clearInterval(id);
          triggerBloodDamage(
            'O tempo acabou! O feitiço te atingiu em cheio!',
            'Tempo de 15s esgotou no livro da bruxa: sangue na tela, dano e perda de ouro!'
          );
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(id);
  }, [state.minigame.type]);

  const handleAimShotgun = () => {
    medievalAudio.unlock('interior');
    medievalAudio.playAimLock();
    setShotgunDrawn(true);
    setAimLocked(true);
    setState((s) => ({
      ...s,
      logMessage: 'Você puxou a 12 e mirou firme no alvo!',
    }));
  };

  const handleFireShotgun = () => {
    medievalAudio.unlock('interior');
    if (!shotgunDrawn) {
      medievalAudio.playAimLock();
      setShotgunDrawn(true);
      setAimLocked(true);
      setState((s) => ({
        ...s,
        logMessage: '12 empunhada e mirada! Aperte ATIRAR novamente para disparar.',
      }));
      return;
    }

    if (state.shotgunAmmo <= 0) {
      triggerBloodDamage(
        'Sem balas na 12! Você ficou sem munição na hora H!',
        'Sem bala na 12: você levou dano e perdeu ouro!'
      );
      return;
    }

    medievalAudio.playShotgunBlast();
    setShotgunRecoil(true);
    window.setTimeout(() => {
      setShotgunRecoil(false);
      setShotgunDrawn(false);
      setAimLocked(false);
    }, 320);

    const v = state.currentVisitor;
    if (!v) return;

    const isThreat =
      v.trueNature === 'stolen_goods' ||
      v.trueNature === 'raider_threat' ||
      v.trueNature === 'witch_curse';

    if (!isThreat) {
      setState((s) => ({
        ...s,
        shotgunAmmo: s.shotgunAmmo - 1,
        reputation: Math.max(0, s.reputation - 10),
        speechBubble: 'Você puxou a 12 e atirou em quem não era ameaça!',
        logMessage: `Bala gasta em alvo não-ameaça (-10 rep). Restam ${s.shotgunAmmo - 1}.`,
      }));
      return;
    }

    const reward = 50 + state.day * 6;
    setState((s) => ({
      ...s,
      shotgunAmmo: s.shotgunAmmo - 1,
      gold: s.gold + reward,
      reputation: s.reputation + 6,
      animStage: 'leaving',
      speechBubble: 'Agh... você mirou e mandou chumbo com a 12...',
      logMessage: `Ameaça abatida com a 12! +${reward}g.`,
    }));

    window.setTimeout(() => {
      setState((s) => advanceToNextVisitor(s));
    }, 2300);
  };

  const handleShootShurikenWithPistol = () => {
    if (state.minigame.type !== 'ninja_shuriken') return;
    medievalAudio.unlock('interior');
    if (state.pistolAmmo <= 0) {
      triggerBloodDamage(
        'Sem balas na pistola! As shurikens acertaram em cheio!',
        'Sem munição de pistola para as shurikens: sangue na tela e dano!'
      );
      return;
    }

    medievalAudio.playPistol();
    const nextHits = shurikenHits + 1;
    setShurikenHits(nextHits);
    setShurikenX(10);
    setShurikenY(22 + Math.floor(Math.random() * 36));
    setState((s) => ({ ...s, pistolAmmo: Math.max(0, s.pistolAmmo - 1) }));

    if (nextHits >= state.minigame.hitsNeeded) {
      medievalAudio.playCoin();
      setState((s) => ({
        ...s,
        gold: s.gold + 65,
        reputation: s.reputation + 7,
        minigame: { type: 'none' },
        animStage: 'leaving',
        speechBubble: 'Você acertou as 5 shurikens com a pistola?! Tô caindo fora!',
        logMessage: '5 shurikens derrubadas com a pistola! +65g.',
      }));
      window.setTimeout(() => {
        setState((s) => advanceToNextVisitor(s));
      }, 2300);
    }
  };

  const handlePickLetter = (r: number, c: number) => {
    if (state.minigame.type !== 'witch_wordsearch') return;
    medievalAudio.playStep();
    const nextSel: [number, number][] = [
      ...pickedCells,
      [r, c] as [number, number],
    ].slice(-5);
    setPickedCells(nextSel);

    for (const [word, coords] of Object.entries(TARGET_WORDS)) {
      if (foundWords.includes(word)) continue;
      if (coords.every(([wr, wc]) => nextSel.some(([sr, sc]) => sr === wr && sc === wc))) {
        medievalAudio.playCoin();
        const updated = [...foundWords, word];
        setFoundWords(updated);
        setPickedCells([]);
        if (updated.length >= 5) {
          setState((s) => ({
            ...s,
            reputation: s.reputation + 8,
            minigame: { type: 'none' },
            animStage: 'leaving',
            speechBubble: 'Você achou as 5 palavras no livro antes dos 15s e quebrou o feitiço!',
            logMessage: 'Feitiço da bruxa quebrado com as 5 palavras!',
          }));
          window.setTimeout(() => {
            setState((s) => advanceToNextVisitor(s));
          }, 2300);
        }
        break;
      }
    }
  };

  const finishVisitorSlowly = (farewell: string, mutateFn?: (s: GameState) => GameState) => {
    medievalAudio.playStep();
    setState((s) => {
      const base = mutateFn ? mutateFn(s) : s;
      return {
        ...base,
        animStage: 'leaving',
        speechBubble: farewell,
        logMessage: farewell,
      };
    });
    window.setTimeout(() => {
      setState((s) => advanceToNextVisitor(s));
    }, 2400);
  };

  // CUTSCENE INICIAL DO ARTHUR (POD -> RUA -> CAMINHÃO -> BALCÃO)
  if (state.viewMode === 'intro_cutscene') {
    return (
      <div
        className="min-h-screen bg-stone-950 text-amber-50 flex flex-col justify-between max-w-2xl mx-auto p-4 select-none"
        style={{ imageRendering: 'pixelated' }}
      >
        <header className="flex items-center justify-between border-b border-stone-800 pb-2 text-xs font-mono">
          <span className="font-black text-amber-300">BALCÃO DO REINO • PRÓLOGO</span>
          <span>CENA {state.cutsceneStep + 1}/3</span>
        </header>

        <section
          className="my-4 h-72 rounded-xl border-2 border-amber-700 p-4 flex flex-col justify-between relative overflow-hidden"
          style={{
            background:
              state.cutsceneStep === 2
                ? 'linear-gradient(to bottom, #450a0a 0%, #1c1917 60%, #09090b 100%)'
                : state.cutsceneStep === 1
                ? 'linear-gradient(to bottom, #1e293b 0%, #0f172a 60%, #18181b 100%)'
                : 'linear-gradient(to bottom, #1e1b4b 0%, #18181b 60%, #27272a 100%)',
          }}
        >
          <div className="flex items-center justify-center my-auto gap-6">
            {state.cutsceneStep === 0 && (
              <>
                <div className="w-16 h-12 bg-sky-950 border-2 border-sky-400 flex items-center justify-center font-mono text-[10px]">
                  GAME
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-[10px] font-mono bg-black/80 px-1.5 py-0.5 rounded mb-1 text-amber-200">
                    ARTHUR
                  </span>
                  <div className="w-5 h-2 bg-stone-800 border border-black" />
                  <div className="w-6 h-5 bg-amber-200 border border-black" />
                  <div className="w-9 h-7 bg-zinc-400 border border-black" />
                </div>
                <div className="px-2 py-1 rounded bg-emerald-950 border border-emerald-500 font-mono text-[10px] text-emerald-200">
                  PODS
                </div>
              </>
            )}

            {state.cutsceneStep === 1 && (
              <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono bg-black/80 px-1.5 py-0.5 rounded mb-1 text-zinc-200">
                  *andando sem olhar para a rua...*
                </span>
                <div className="w-5 h-2 bg-stone-800 border border-black" />
                <div className="w-6 h-5 bg-amber-200 border border-black" />
                <div className="w-9 h-7 bg-zinc-400 border border-black" />
              </div>
            )}

            {state.cutsceneStep === 2 && (
              <div className="flex items-center gap-4">
                <div className="w-24 h-14 bg-red-900 border-4 border-amber-300 flex flex-col justify-between p-1 font-mono text-[10px] font-black">
                  <span>CAMINHÃO</span>
                  <div className="flex justify-between">
                    <span className="w-3 h-3 bg-yellow-300 border border-black" />
                    <span className="w-3 h-3 bg-yellow-300 border border-black" />
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-red-950 border border-red-400 font-mono text-xs font-black text-amber-200">
                  ★ POW! ★
                </span>
              </div>
            )}
          </div>

          <p className="text-xs sm:text-sm font-mono bg-black/85 border border-amber-700/70 rounded-lg p-3 text-amber-100 leading-relaxed">
            {state.cutsceneStep === 0 &&
              'Arthur era meio gordinho, vivia só jogando e passando pod ilegal na surdina. Não fazia mais nada da vida.'}
            {state.cutsceneStep === 1 &&
              'Ele saiu na rua sem ligar para nada e sem olhar para os lados...'}
            {state.cutsceneStep === 2 &&
              'Um caminhão atropelou ele em cheio. Quando a escuridão abriu, você estava atrás de um balcão medieval.'}
          </p>
        </section>

        <div className="flex justify-between gap-2">
          <button
            type="button"
            onClick={() => {
              medievalAudio.unlock('interior');
              setState((s) => ({
                ...s,
                viewMode: 'interior',
                logMessage: 'Arthur acordou atrás do balcão medieval! Dia 1 começou.',
              }));
            }}
            className="px-3 py-2.5 rounded-lg bg-stone-800 text-xs font-mono font-bold text-stone-300 cursor-pointer"
          >
            PULAR ANIMAÇÃO
          </button>

          <button
            type="button"
            onClick={() => {
              medievalAudio.unlock('interior');
              if (state.cutsceneStep < 2) {
                medievalAudio.playStep();
                setState((s) => ({ ...s, cutsceneStep: s.cutsceneStep + 1 }));
              } else {
                medievalAudio.playTruckCrash();
                setState((s) => ({
                  ...s,
                  viewMode: 'interior',
                  logMessage: 'O caminhão acertou em cheio — bem-vindo ao Balcão do Reino!',
                }));
              }
            }}
            className="px-4 py-2.5 rounded-lg bg-amber-700 hover:bg-amber-600 text-xs font-mono font-black text-white cursor-pointer"
          >
            {state.cutsceneStep < 2 ? 'PRÓXIMA CENA ▶' : 'ENTRAR NA LOJA ▶'}
          </button>
        </div>
      </div>
    );
  }

  const visitor = state.currentVisitor;
  const isWitchAura = visitor?.archetype === 'witch';
  const isMythicAura =
    visitor?.trueNature === 'legend_relic' || visitor?.trueNature === 'mythic_relic';
  const isDirectNinja =
    state.minigame.type === 'ninja_shuriken' && visitor?.archetype === 'ninja_raider';

  return (
    <div
      className="min-h-screen bg-stone-950 text-amber-50 flex flex-col max-w-6xl mx-auto select-none"
      style={{ imageRendering: 'pixelated' }}
    >
      {/* Topo */}
      <header className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-stone-900 border-b-2 border-amber-800/80">
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <span className="text-sm sm:text-base font-black text-amber-300">
            BALCÃO DO REINO • ARTHUR
          </span>
          <span className="px-2 py-0.5 rounded bg-stone-800">DIA {state.day}</span>
          <span className="px-2 py-0.5 rounded bg-stone-800 text-yellow-300">{state.gold}g</span>
          <span className="px-2 py-0.5 rounded bg-stone-800 text-emerald-300">
            REP {state.reputation}
          </span>
          <span className="px-2 py-0.5 rounded bg-stone-800 text-red-300">
            12: {state.shotgunAmmo}
          </span>
          <span className="px-2 py-0.5 rounded bg-stone-800 text-sky-300">
            PISTOLA: {state.pistolAmmo}
          </span>
          <span className="px-2 py-0.5 rounded bg-stone-800 text-amber-200">
            AVALIAR: {state.appraisalsLeft}/2
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {state.viewMode === 'interior' ? (
            <button
              type="button"
              onClick={() => {
                medievalAudio.playStep();
                setState((s) => enterExteriorNight(s));
              }}
              className="px-3 py-1.5 rounded bg-indigo-900 border border-indigo-500 text-xs font-extrabold font-mono cursor-pointer"
            >
              EXTERIOR / NOITE
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                medievalAudio.playCoin();
                setState((s) => startNextDayFromNight(s));
              }}
              className="px-3 py-1.5 rounded bg-amber-700 border border-amber-400 text-xs font-extrabold font-mono cursor-pointer"
            >
              PRÓXIMO DIA
            </button>
          )}
          <button
            type="button"
            onClick={() => setState((s) => ({ ...s, muted: !s.muted }))}
            className="px-2.5 py-1.5 rounded bg-stone-800 border border-stone-600 text-xs font-bold font-mono cursor-pointer"
          >
            {state.muted ? 'SOM: OFF' : 'SOM: ON'}
          </button>
          <button
            type="button"
            onClick={() => setState(createInitialGameState(state.muted))}
            className="px-2.5 py-1.5 rounded bg-red-950 border border-red-800 text-xs font-bold font-mono cursor-pointer"
          >
            RESET
          </button>
        </div>
      </header>

      {/* Barra de Status */}
      <div className="px-4 py-1.5 bg-stone-900/80 border-b border-stone-800 text-xs font-mono text-amber-200 flex flex-wrap justify-between gap-2">
        <span>{state.logMessage}</span>
        <span>
          HP LOJA: {state.shopHp}/{state.maxShopHp} • SUSPEITA: {state.suspicion}%
        </span>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 p-3">
        <main className="lg:col-span-8 flex flex-col gap-3">
          {state.viewMode === 'interior' ? (
            <section
              className={`relative w-full h-80 sm:h-96 rounded-xl border-2 overflow-hidden transition-shadow ${
                isWitchAura
                  ? 'border-purple-500 shadow-[inset_0_0_55px_rgba(168,85,247,0.55)]'
                  : isMythicAura
                  ? 'border-amber-400 shadow-[inset_0_0_45px_rgba(250,204,21,0.35)]'
                  : 'border-amber-800'
              }`}
              style={{
                background:
                  'linear-gradient(to bottom, #2a231e 0%, #181412 58%, #3c2a1e 58%, #22160e 100%)',
              }}
            >
              {/* Estante Esquerda: Poções & Frascos */}
              <div className="absolute left-3 top-6 w-24 h-28 bg-amber-950 border-2 border-amber-700 p-1.5 flex flex-col justify-between">
                <div className="grid grid-cols-3 gap-1">
                  <div className="h-4 bg-red-500 border border-black" />
                  <div className="h-4 bg-emerald-400 border border-black" />
                  <div className="h-4 bg-sky-400 border border-black" />
                </div>
                <div className="h-1 bg-amber-600" />
                <div className="grid grid-cols-3 gap-1">
                  <div className="h-4 bg-purple-500 border border-black" />
                  <div className="h-4 bg-amber-300 border border-black" />
                  <div className="h-4 bg-teal-400 border border-black" />
                </div>
              </div>

              {/* Estante Fundo-Esquerda: Armas & Escudos */}
              <div className="absolute left-32 top-7 w-24 h-24 bg-stone-900 border-2 border-amber-800 p-1.5 flex items-end justify-around">
                <div className="w-2 h-16 bg-stone-300 border border-black" />
                <div className="w-7 h-7 rounded-full bg-amber-700 border-2 border-amber-300" />
                <div className="w-2 h-14 bg-sky-300 border border-black" />
              </div>

              {/* Porta de Entrada no Centro */}
              <div className="absolute left-1/2 -translate-x-1/2 top-5 w-20 h-28 bg-sky-950 border-4 border-amber-900 flex flex-col justify-between items-center p-1">
                <span className="text-[9px] font-mono bg-black/75 px-1 text-amber-200">
                  {state.animStage === 'leaving' ? 'SAINDO' : 'PORTA'}
                </span>
                <div className="w-full h-2 bg-amber-700" />
              </div>

              {/* Estante Fundo-Direita: Pergaminhos & Livros */}
              <div className="absolute right-32 top-7 w-24 h-24 bg-stone-900 border-2 border-amber-800 p-1.5 grid grid-cols-2 gap-1">
                <div className="bg-amber-200 border border-black" />
                <div className="bg-red-800 border border-black" />
                <div className="bg-emerald-700 border border-black" />
                <div className="bg-amber-400 border border-black" />
              </div>

              {/* Estante Direita: Relíquias & Cristais */}
              <div className="absolute right-3 top-6 w-24 h-28 bg-amber-950 border-2 border-amber-700 p-1.5 flex flex-col justify-between">
                <div className="flex justify-around">
                  <div className="w-4 h-6 bg-cyan-300 border border-black" />
                  <div className="w-4 h-6 bg-amber-400 border border-black" />
                </div>
                <div className="h-1 bg-amber-600" />
                <div className="w-full h-6 bg-stone-700 border border-black flex items-center justify-center text-[9px] font-mono">
                  COFRE
                </div>
              </div>

              {/* Tochas laterais */}
              <div className="absolute left-60 top-14 w-2.5 h-7 bg-amber-950 border border-amber-700">
                <div
                  className={`w-2.5 h-2.5 -mt-2 animate-pulse ${
                    isWitchAura
                      ? witchFlicker
                        ? 'bg-purple-400'
                        : 'bg-fuchsia-700'
                      : 'bg-orange-400'
                  }`}
                />
              </div>
              <div className="absolute right-60 top-14 w-2.5 h-7 bg-amber-950 border border-amber-700">
                <div
                  className={`w-2.5 h-2.5 -mt-2 animate-pulse ${
                    isWitchAura
                      ? witchFlicker
                        ? 'bg-fuchsia-400'
                        : 'bg-purple-800'
                      : 'bg-orange-400'
                  }`}
                />
              </div>

              {/* Visitante + Balão de fala */}
              {visitor && (
                <div
                  style={{
                    left: '50%',
                    top:
                      state.animStage === 'entering'
                        ? '29%'
                        : state.animStage === 'leaving'
                        ? '28%'
                        : '45%',
                  }}
                  className="-translate-x-1/2 -translate-y-1/2 absolute z-10 flex flex-col items-center transition-all duration-300"
                >
                  {state.speechBubble && (
                    <div className="mb-2 max-w-xs px-2.5 py-1.5 rounded-lg bg-amber-50 text-stone-950 border-2 border-stone-900 text-xs font-bold text-center shadow-lg">
                      {state.speechBubble}
                    </div>
                  )}

                  <span className="px-1.5 py-0.5 mb-1 rounded bg-black/85 border border-amber-500/60 text-[10px] font-mono text-amber-200 whitespace-nowrap">
                    {visitor.name} • {visitor.coverRole}
                  </span>

                  <div className={`visitor-sprite visitor-${visitor.archetype} ${state.animStage === 'entering' ? 'sprite-enter' : state.animStage === 'leaving' ? 'sprite-leave' : ''}`}>
                      {aimLocked && <div className="sprite-crosshair">＋</div>}
                      <div className="sprite-shadow" /><div className="sprite-cape" style={{ backgroundColor: visitor.shirtColor }} />
                      <div className="sprite-head" style={{ backgroundColor: '#d9a477' }}>
                        <i className="sprite-hair" style={{ backgroundColor: visitor.hairColor }} />
                        <i className="sprite-eye eye-left" /><i className="sprite-eye eye-right" /><i className="sprite-nose" /><i className="sprite-mouth" />
                        <i className="sprite-ear ear-left" /><i className="sprite-ear ear-right" />
                      </div><div className="sprite-neck" />
                      <div className="sprite-torso" style={{ backgroundColor: visitor.shirtColor }}>
                        <i className="sprite-belt" /><i className="sprite-buckle" style={{ backgroundColor: visitor.accentColor }} /><i className="sprite-arm arm-left" /><i className="sprite-arm arm-right" />
                      </div><div className="sprite-legs"><i /><i /></div>
                    </div>
                </div>
              )}

              {/* Minigame Ninja: 5 Shurikens rápidas com pistola */}
              {state.minigame.type === 'ninja_shuriken' && (
                <div className="absolute inset-3 z-30 rounded-xl bg-black/90 border-2 border-red-600 p-3 flex flex-col justify-between">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-red-400 font-black">
                      LUTA DIRETA! ACERTE {state.minigame.hitsNeeded} SHURIKENS ({shurikenHits}/5)
                    </span>
                    <span className="text-sky-300">PISTOLA: {state.pistolAmmo}</span>
                  </div>
                  <div className="relative flex-1 my-2 rounded-lg bg-stone-900 border border-stone-700 overflow-hidden">
                    <button
                      type="button"
                      onClick={handleShootShurikenWithPistol}
                      style={{ left: `${shurikenX}%`, top: `${shurikenY}%` }}
                      className="-translate-x-1/2 -translate-y-1/2 absolute px-2.5 py-1.5 rounded bg-red-600 text-white font-mono text-xs font-black border-2 border-white animate-spin cursor-pointer"
                    >
                      ✦
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={handleShootShurikenWithPistol}
                    className="py-2 rounded-lg bg-sky-700 hover:bg-sky-600 font-mono text-xs font-black cursor-pointer"
                  >
                    ATIRAR COM PISTOLA
                  </button>
                </div>
              )}

              {/* Minigame Bruxa: Livro + Caça-Palavras de 5 palavras + Cronômetro 15s */}
              {state.minigame.type === 'witch_wordsearch' && (
                <div className="absolute inset-2 z-30 rounded-xl bg-amber-950/95 border-2 border-purple-400 p-3 flex flex-col justify-between">
                  <div className="flex flex-wrap justify-between gap-1 text-xs font-mono">
                    <span className="font-black text-purple-200">
                      LIVRO ARCANO — ACHE 5 PALAVRAS ({foundWords.length}/5)
                    </span>
                    <span className="text-red-300 font-black">TEMPO: {witchTimer}s</span>
                  </div>
                  <p className="text-[11px] font-mono text-amber-200">
                    Palavras:{' '}
                    {(['LUZ', 'ALMA', 'FOGO', 'ROCHA', 'RUNA'] as const).map((w, idx) => (
                      <span
                        key={w}
                        className={
                          foundWords.includes(w)
                            ? 'line-through text-emerald-400 mr-2'
                            : 'mr-2'
                        }
                      >
                        {w}
                        {idx < 4 ? ',' : ''}
                      </span>
                    ))}
                  </p>
                  <div className="grid grid-cols-6 gap-1 max-w-[250px] mx-auto">
                    {WORD_GRID.map((row, r) =>
                      row.map((ch, c) => {
                        const sel = pickedCells.some(([pr, pc]) => pr === r && pc === c);
                        return (
                          <button
                            key={`${r}-${c}`}
                            type="button"
                            onClick={() => handlePickLetter(r, c)}
                            className={`w-8 h-8 rounded font-mono text-xs font-black border cursor-pointer ${
                              sel
                                ? 'bg-amber-400 text-stone-950 border-white'
                                : 'bg-black/45 text-amber-100 border-amber-700'
                            }`}
                          >
                            {ch}
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* Sangue + Tela Vermelha ao falhar */}
              {bloodScreen && (
                <div className="absolute inset-0 z-40 pointer-events-none bg-red-700/65 border-4 border-red-300 flex items-center justify-center">
                  <div className="px-4 py-3 rounded bg-red-950/95 border-2 border-red-300 font-mono text-xs font-black text-red-200 shadow-xl">
                    🩸 SANGUE • DANO SOFRIDO! 🩸
                  </div>
                </div>
              )}

              {/* A 12 desenhada na mão do Arthur em 1ª pessoa */}
              {shotgunDrawn && (
                <div
                  className={`-bottom-2 right-12 z-30 absolute pointer-events-none transition-transform duration-150 ${
                    aimLocked ? '-translate-y-4 -translate-x-4 scale-105' : ''
                  } ${shotgunRecoil ? 'translate-y-3 rotate-3' : ''}`}
                >
                  <div className="weapon-shotgun"><i className="gun-stock" /><i className="gun-grip" /><i className="gun-trigger" /><i className="gun-barrel" /><i className="gun-under" />{shotgunRecoil && <i className="gun-flash" />}</div>
                </div>
              )}

              {/* Balcão em 1ª pessoa */}
              <div className="absolute inset-x-0 bottom-0 h-16 z-20 bg-amber-900 border-t-4 border-amber-500 flex items-center justify-between px-4 text-xs font-mono">
                <span className="bg-amber-100 text-stone-950 px-2 py-0.5 rounded border border-stone-900 font-bold">
                  BALCÃO DE ARTHUR
                </span>
                {visitor && !isDirectNinja && (
                  <span className="px-2.5 py-1 rounded bg-stone-950/90 border border-amber-500/70 text-amber-200">
                    {visitor.item.name} ({state.currentOffer}g)
                  </span>
                )}
              </div>
            </section>
          ) : (
            <section className="relative w-full h-80 sm:h-96 rounded-xl border-2 border-indigo-700 overflow-hidden bg-indigo-950 p-4 flex flex-col justify-between">
              <div className="flex justify-between text-xs font-mono bg-black/75 p-2.5 rounded border border-indigo-500/50">
                <span>FORTALEZA NÍVEL {state.fortressLevel}/4</span>
                <span>GUARDAS: {state.guardsCount} (MENINO NV.{state.boyGuardLevel})</span>
              </div>
              <p className="text-xs font-mono bg-black/80 p-3 rounded border border-amber-500/60 text-amber-100">
                {state.nightReport || 'Vigília noturna no exterior da loja.'}
              </p>
            </section>
          )}

          {/* Controles do Balcão (ocultos quando o ninja já puxou luta direta) */}
          {state.viewMode === 'interior' && visitor && !isDirectNinja && (
            <section className="rounded-xl bg-stone-900 border border-stone-800 p-3 space-y-2.5">
              <div className="flex flex-wrap gap-1.5">
                {visitor.dialogues.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => {
                      medievalAudio.playStep();
                      setState((s) => ({
                        ...s,
                        speechBubble: d.reply,
                        visitorPatience: Math.max(0, s.visitorPatience + (d.moodShift ?? 0)),
                      }));
                    }}
                    className="px-2.5 py-1.5 rounded bg-stone-800 hover:bg-stone-700 border border-stone-600 text-xs font-bold cursor-pointer"
                  >
                    “{d.label}”
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                <button
                  type="button"
                  disabled={state.appraisalsLeft <= 0}
                  onClick={() => {
                    medievalAudio.playCoin();
                    setState((s) => evaluateCurrentItem(s));
                  }}
                  className="py-2.5 px-2 rounded-lg bg-amber-800 hover:bg-amber-700 disabled:opacity-40 text-xs font-black font-mono cursor-pointer"
                >
                  AVALIAR ({state.appraisalsLeft}/2)
                </button>

                <button
                  type="button"
                  onClick={() => {
                    medievalAudio.playCoin();
                    setState((s) => buyFromCounter(s));
                  }}
                  className="py-2.5 px-2 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-xs font-black font-mono cursor-pointer"
                >
                  COMPRAR ({state.currentOffer}g)
                </button>

                <button
                  type="button"
                  onClick={handleAimShotgun}
                  className={`py-2.5 px-2 rounded-lg text-xs font-black font-mono border cursor-pointer ${
                    aimLocked
                      ? 'bg-red-600 border-yellow-300 text-white'
                      : 'bg-stone-800 border-red-500 text-red-200'
                  }`}
                >
                  {aimLocked ? 'MIRANDO ✓' : 'MIRAR 12'}
                </button>

                <button
                  type="button"
                  onClick={handleFireShotgun}
                  className="py-2.5 px-2 rounded-lg bg-red-800 hover:bg-red-700 text-white text-xs font-black font-mono cursor-pointer"
                >
                  ATIRAR ({state.shotgunAmmo})
                </button>

                <button
                  type="button"
                  onClick={() =>
                    finishVisitorSlowly('Até a próxima, lojista...', (s) => s)
                  }
                  className="py-2.5 px-2 rounded-lg bg-stone-800 hover:bg-stone-700 border border-stone-600 text-xs font-bold font-mono cursor-pointer"
                >
                  DISPENSAR
                </button>
              </div>
            </section>
          )}
        </main>

        {/* Painel Lateral */}
        <aside className="lg:col-span-4 rounded-xl bg-stone-900 border-2 border-amber-800/80 p-3 flex flex-col gap-3">
          <div className="grid grid-cols-5 gap-1">
            {(['upgrade', 'repair', 'buy', 'trade', 'banco'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  medievalAudio.playHammer();
                  setSideTab(t);
                }}
                className={`py-2 rounded text-[10px] font-black font-mono border uppercase cursor-pointer ${
                  sideTab === t
                    ? 'bg-amber-700 border-amber-300 text-white'
                    : 'bg-stone-950 border-stone-800 text-stone-400'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {sideTab === 'buy' && (
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  if (state.gold < 95) return;
                  medievalAudio.playCoin();
                  setState((s) => ({
                    ...s,
                    gold: s.gold - 95,
                    shotgunAmmo: s.shotgunAmmo + 2,
                    logMessage: 'Comprou +2 balas de 12 (munição cara!).',
                  }));
                }}
                className="w-full py-2 px-3 rounded-lg bg-red-950 border border-red-700 text-xs font-mono flex justify-between cursor-pointer"
              >
                <span>+2 Balas de 12 (Caro)</span>
                <span className="text-yellow-300">95g</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (state.gold < 65) return;
                  medievalAudio.playCoin();
                  setState((s) => ({
                    ...s,
                    gold: s.gold - 65,
                    pistolAmmo: s.pistolAmmo + 8,
                    logMessage: 'Comprou +8 balas de pistola (65g).',
                  }));
                }}
                className="w-full py-2 px-3 rounded-lg bg-sky-950 border border-sky-700 text-xs font-mono flex justify-between cursor-pointer"
              >
                <span>+8 Balas de Pistola</span>
                <span className="text-yellow-300">65g</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (state.gold < 60) return;
                  medievalAudio.playCoin();
                  const rolled = rollVariantItem('ring', 'crate');
                  setState((s) => ({
                    ...s,
                    gold: s.gold - 60,
                    inventory: [...s.inventory, rolled],
                    logMessage: `Comprou ${rolled.name} (60g).`,
                  }));
                }}
                className="w-full py-2 px-3 rounded-lg bg-stone-950 border border-stone-700 text-xs font-mono flex justify-between cursor-pointer"
              >
                <span>Caixa de Item (Chance Rara)</span>
                <span className="text-yellow-300">60g</span>
              </button>
              {MYTHIC_DEFENSE_ITEMS.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    if (state.gold < m.baseValue) return;
                    medievalAudio.playCoin();
                    setState((s) => ({
                      ...s,
                      gold: s.gold - m.baseValue,
                      inventory: [...s.inventory, { ...m, id: `${m.id}-${Date.now()}` }],
                      logMessage: `Comprou ${m.name} (${m.baseValue}g).`,
                    }));
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-stone-950 border border-purple-900/60 text-xs font-bold flex justify-between cursor-pointer"
                >
                  <span>{m.name}</span>
                  <span className="font-mono text-yellow-300">{m.baseValue}g</span>
                </button>
              ))}
            </div>
          )}

          {sideTab === 'upgrade' && (
            <div className="space-y-2 max-h-[420px] overflow-y-auto">
              {state.upgrades.map((u) => {
                const cost = getUpgradeCost(u.baseCost, u.level);
                return (
                  <div
                    key={u.id}
                    className="rounded-lg bg-stone-950 border border-stone-800 p-2.5 space-y-1.5"
                  >
                    <div className="flex justify-between text-xs font-bold">
                      <span>{u.name}</span>
                      <span className="font-mono text-stone-400">Nv.{u.level}</span>
                    </div>
                    <p className="text-[11px] text-stone-400">{u.description}</p>
                    <button
                      type="button"
                      disabled={state.gold < cost}
                      onClick={() => {
                        medievalAudio.playHammer();
                        setState((s) => ({
                          ...s,
                          gold: s.gold - cost,
                          boyGuardLevel:
                            u.id === 'guards' ? s.boyGuardLevel + 1 : s.boyGuardLevel,
                          guardsCount:
                            u.id === 'guards' ? Math.min(6, s.guardsCount + 1) : s.guardsCount,
                          guardsPower: u.id === 'guards' ? s.guardsPower + 15 : s.guardsPower,
                          witchWardPower:
                            u.id === 'witch_ward' ? s.witchWardPower + 15 : s.witchWardPower,
                          fortressLevel:
                            u.id === 'fortress'
                              ? Math.min(4, s.fortressLevel + 1)
                              : s.fortressLevel,
                          upgrades: s.upgrades.map((item) =>
                            item.id === u.id ? { ...item, level: item.level + 1 } : item
                          ),
                          logMessage: `Melhorou ${u.name} (-${cost}g)!`,
                        }));
                      }}
                      className="w-full py-1.5 rounded bg-amber-800 disabled:opacity-40 text-xs font-mono font-bold cursor-pointer"
                    >
                      MELHORAR ({cost}g)
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {sideTab === 'repair' && (
            <div className="space-y-2">
              {state.repairs.map((r) => (
                <div
                  key={r.id}
                  className="rounded-lg bg-stone-950 border border-stone-800 p-2.5 flex items-center justify-between text-xs"
                >
                  <span>
                    {r.name} ({r.durability}%)
                  </span>
                  <button
                    type="button"
                    disabled={state.gold < r.cost}
                    onClick={() => {
                      medievalAudio.playHammer();
                      setState((s) => ({
                        ...s,
                        gold: s.gold - r.cost,
                        shopHp: Math.min(s.maxShopHp, s.shopHp + 15),
                        repairs: s.repairs.map((item) =>
                          item.id === r.id ? { ...item, durability: 100 } : item
                        ),
                        logMessage: `Arrumou ${r.name} (-${r.cost}g)!`,
                      }));
                    }}
                    className="px-2.5 py-1.5 rounded bg-amber-800 disabled:opacity-40 font-mono font-bold cursor-pointer"
                  >
                    ARRUMAR ({r.cost}g)
                  </button>
                </div>
              ))}
            </div>
          )}

          {sideTab === 'trade' && (
            <div className="space-y-2 max-h-[420px] overflow-y-auto">
              {state.inventory.map((item, idx) => (
                <div
                  key={`${item.id}-${idx}`}
                  className="rounded-lg bg-stone-950 border border-stone-800 p-2.5 flex items-center justify-between gap-2 text-xs"
                >
                  <div>
                    <p className="font-bold">{item.name}</p>
                    <p className="text-[11px] text-stone-400">Valor: {item.baseValue}g</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      medievalAudio.playCoin();
                      const gain = Math.round(item.baseValue * 1.25);
                      setState((s) => ({
                        ...s,
                        gold: s.gold + gain,
                        inventory: s.inventory.filter((_, i) => i !== idx),
                        logMessage: `Vendeu ${item.name} por +${gain}g!`,
                      }));
                    }}
                    className="px-2.5 py-1.5 rounded bg-emerald-800 font-mono font-bold shrink-0 cursor-pointer"
                  >
                    VENDER (+{Math.round(item.baseValue * 1.25)}g)
                  </button>
                </div>
              ))}
            </div>
          )}

          {sideTab === 'banco' && (
            <div className="space-y-2 text-xs">
              {state.loans.map((loan) => (
                <div
                  key={loan.id}
                  className="rounded-lg bg-stone-950 border border-stone-800 p-2.5 space-y-1.5"
                >
                  <div className="flex justify-between font-bold">
                    <span>{loan.lender}</span>
                    <span className="font-mono text-yellow-300">+{loan.principal}g</span>
                  </div>
                  <button
                    type="button"
                    disabled={loan.taken || state.isCollapseEra}
                    onClick={() => {
                      medievalAudio.playCoin();
                      setState((s) => takeBankLoan(s, loan.id));
                    }}
                    className="w-full py-1.5 rounded bg-amber-800 disabled:opacity-40 font-mono font-bold cursor-pointer"
                  >
                    {loan.defaultedInCollapse
                      ? 'COLAPSADO'
                      : loan.taken
                      ? 'ATIVO'
                      : 'PEGAR EMPRÉSTIMO'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

export default App;
